# TaskMaster Concept (Source of Truth)

## Purpose
TaskMaster helps users turn thoughts into action through fast task capture, clear daily execution, and adaptive AI support. The core promise is a rewarding daily loop: create tasks quickly, complete tasks easily, feel meaningful progress, and keep coming back because the experience is satisfying without pressure-heavy UX.

## Product Identity
- AI-powered task manager first, gamification second.
- Encouraging tone over guilt/shame messaging.
- Works in two usable modes:
  - `minimal`: focused productivity.
  - `gamified`: progression/reward layer on top of productivity.

## Core Principles
1. **Action over planning overhead**: users can quickly capture intent in plain language and apply updates in bulk (for example, "I did X, Y, and Z today").
2. **Consistency beats intensity**: reward small repeatable wins.
3. **Personalized but user-controlled**: AI should adapt to user context, with clear controls and opt-out.
4. **Balance-aware guidance**: suggestions should help neglected life areas (productivity, fun, relaxation, social, health).
5. **Core-first execution**: keep auth, onboarding, task CRUD, scheduling, recurrence, suggestions, sync, and settings stable before broader expansion.

## Critical Requirements (From Source Prompts)
- **Tool + game independence**: task manager must be excellent on its own; gamified layer must add motivation without becoming required.
- **Multi-modal capture**: support text-first now, with voice recap and photo-assisted logging as planned expansion paths.
- **Daily check-in loop (30-60 seconds)**: lightweight review of what was done, what changed, and what to do next.
- **Goal decomposition**: convert larger goals into small actionable steps and connect daily execution to milestones.
- **Adaptive challenge control**: users choose how much they are pushed (comfort-zone/intensity controls).
- **Reward personalization**: users should be able to prefer different reward styles while preserving the same core task flow.
- **Self-discovery onboarding**: include guided prompts and an "I don't know, help me with this" branch.
- **Guidance everywhere, never pushy**: suggestions should be useful across major flows, with supportive tone and easy dismiss/shuffle feedback.

## Existing Foundation (Do Not Re-add As New Features)
The app already includes these major capabilities:
- Auth + Firestore-backed persistence/sync.
- Onboarding flow and starter task generation.
- Task CRUD with scheduling, deadlines, and recurrence.
- AI enrichment + AI suggestions (Today + Explore).
- Persona/profile synthesis and clarification-question flow.
- Gamified progression paths (quests/rewards/XP) plus minimal mode.
- Theme system and mode/theme settings.
- Group/sort/filter behavior in Today view.

Use this section as a guardrail when writing TODO items so duplicates are not added.

## North Star User Loop
1. Capture intent quickly (quick add / natural language).
2. Get actionable output immediately (task, plan, or suggestion).
3. Execute with satisfying feedback and minimal friction.
4. Receive adaptive suggestions based on progress and preferences.
5. Repeat daily with compounding personalization.

## UX Direction
- Keep all primary actions available from the Today workflow.
- Prefer one-screen completability for common actions and avoid extra manual steps.
- Make AI actions explicit ("what the app is about to do") before commit, then let users confirm or edit.
- Support both guided and manual control paths on major flows.

## AI Behavior Requirements
- All AI responses are structured JSON through `claudeService`.
- AI should provide clear, bounded outputs (task/suggestion/plan objects), not ambiguous prose.
- Respect personalization boundaries:
  - AI on/off capability.
  - Adjustable suggestion frequency/intensity.
  - Transparent use of user feedback (`too easy`, `too hard`, `not for me`, etc.).
  - Manual-first fallback path that remains fully usable without AI.

## Data/Platform Constraints
- Firestore remains canonical source for user/task/quest data.
- No API keys in code; env-only secrets.
- No new router; single-page app with state-switched views.

## Prioritization Filter (Use For Any New Idea)
Ship ideas that score high on:
1. Improves daily task execution speed or clarity.
2. Improves suggestion relevance or trust.
3. Strengthens retention through lightweight habit loops.
4. Has low implementation risk relative to impact.

Defer ideas that are high complexity and weakly connected to core loop.

## Not Yet Core (Future / Optional)
- Deep social features.
- Heavy mini-game ecosystems.
- Broad external integrations (wearables, third-party APIs) before core flows are excellent.
- Extensive monetization mechanics before retention/fit metrics stabilize.
